<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
try {
    require __DIR__.'/bootstrap.php';
    $action=$_GET['action'] ?? 'state';
    $read=['state','rooms','room','admin_data','export'];
    $input=[];
    if (!in_array($action,$read,true)) {
        if ($_SERVER['REQUEST_METHOD']!=='POST') sf_fail('POST required.',405);
        sf_csrf();
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>100000) sf_fail('Request too large.',413);
        $input=json_decode(file_get_contents('php://input'),true,32,JSON_THROW_ON_ERROR);
        if (!is_array($input)) sf_fail('Invalid request.');
    }
    $pid=(string)($input['project'] ?? $_GET['project'] ?? '');
    if (in_array($action,['login','authenticate'],true)) {
        sf_rate('ip:'.($_SERVER['REMOTE_ADDR'] ?? 'local'),300,900);
        sf_rate($action==='login' ? 'admin' : 'pin:'.$pid.':'.($input['participant'] ?? ''), $action==='login'?30:5,900);
    }
    $out=sf_store(function (&$db) use ($action,$input,$pid) {
        switch ($action) {
            case 'state': return ['csrf'=>$_SESSION['csrf'],'installed'=>(bool)$db['admin'],'admin'=>!empty($_SESSION['admin'])];
            case 'login':
                if (!$db['admin'] || !password_verify((string)($input['password'] ?? ''),$db['admin'])) sf_fail('Sign-in failed.',401);
                session_regenerate_id(true); unset($_SESSION['participant']); $_SESSION['admin']=true; return ['ok'=>true];
            case 'logout': $_SESSION=['csrf'=>bin2hex(random_bytes(32)),'last'=>time()]; session_regenerate_id(true); return ['ok'=>true];
            case 'rooms': return ['rooms'=>array_values(array_map(fn($p)=>['id'=>$p['id'],'name'=>$p['name'],'active'=>$p['active']],$db['projects']))];
            case 'room':
                $p=$db['projects'][$pid] ?? null;
                if (!$p) sf_fail('Room not found.',404);
                if (!$p['active']) return ['id'=>$p['id'],'name'=>$p['name'],'active'=>false,'participants'=>[]];
                return ['id'=>$p['id'],'name'=>$p['name'],'active'=>true,'participants'=>sf_safe_people($p['people'])];
            case 'authenticate':
                unset($_SESSION['participant']);
                $p=$db['projects'][$pid] ?? null; $person=$p['people'][$input['participant'] ?? ''] ?? null;
                if (!$p || !$p['active'] || !$person || !password_verify((string)($input['pin'] ?? ''),$person['hash'])) sf_fail('Identity not accepted. Check your name and PIN, or ask the organizer.',401);
                session_regenerate_id(true); unset($_SESSION['admin']);
                $_SESSION['participant']=['project'=>$pid,'id'=>$person['id'],'version'=>$person['version'],'started'=>time()];
                return ['ok'=>true,'name'=>$person['name'],'minimumSeconds'=>90];
            case 'reveal':
                $s=$_SESSION['participant'] ?? null;
                if (!$s) sf_fail('Please verify your identity again.',401);
                if (!isset($db['projects'][$s['project']])) sf_fail('This room has been deleted.',403);
                $p=&$db['projects'][$s['project']]; $person=$p['people'][$s['id']] ?? null;
                if (!$person || !$p['active'] || !$p['finalized'] || $person['version']!==$s['version']) sf_fail('This mission is unavailable. Ask your organizer.',403);
                if (time()-$s['started']<90) sf_fail('Calibration is still running. Please finish your mission briefing.',409);
                sf_draw_on_reveal($p);
                $friend=$p['people'][$p['assignments'][$s['id']]];
                $p['viewed'][$s['id']] ??= gmdate('c');
                return ['name'=>$friend['name'],'country'=>$friend['country'],'viewedAt'=>$p['viewed'][$s['id']]];
        }
        sf_admin();
        if ($action==='admin_data') {
            $projects=[];
            foreach ($db['projects'] as $p) $projects[]=sf_admin_project($p);
            return ['projects'=>$projects];
        }
        if ($action==='create') {
            $id=sf_id(); $db['projects'][$id]=['id'=>$id,'name'=>sf_text($input['name'] ?? ''),'active'=>false,'finalized'=>false,'people'=>[],'locks'=>[],'assignments'=>[],'viewed'=>[]];
            return ['id'=>$id];
        }
        if (!isset($db['projects'][$pid])) sf_fail('Project not found.',404);
        if ($action==='delete_project') {
            unset($db['projects'][$pid]);
            return ['ok'=>true];
        }
        $p=&$db['projects'][$pid];
        switch ($action) {
            case 'reopen': sf_reopen($p); break;
            case 'rename': $p['name']=sf_text($input['name'] ?? ''); break;
            case 'access':
                if (empty($p['finalized']) && !empty($input['active'])) sf_fail('Seal the room before opening participant access.');
                $p['active']=!empty($input['active']); break;
            case 'participant':
                $id=(string)($input['id'] ?? '');
                if ($id && !isset($p['people'][$id])) sf_fail('Participant not found.',404);
                if (!$id) sf_draft($p);
                if ($p['finalized'] && ($input['name']!==$p['people'][$id]['name'] || $input['country']!==$p['people'][$id]['country'])) sf_fail('Names and countries are locked after finalization. PIN reset is still available.');
                $name=sf_text($input['name'] ?? ''); $country=sf_text($input['country'] ?? '',60);
                $old=$p['people'][$id] ?? null;
                $hash=($input['pin'] ?? '')!=='' ? sf_pin($input['pin']) : ($old['hash'] ?? sf_fail('A PIN is required.'));
                $id=$id ?: sf_id();
                $p['people'][$id]=['id'=>$id,'name'=>$name,'country'=>$country,'hash'=>$hash,'version'=>($old['version'] ?? 0)+1];
                if (!$p['finalized']) $p['assignments']=[];
                break;
            case 'import':
                sf_draft($p); $lines=preg_split('/\R/',sf_text($input['text'] ?? '',60000)); $added=[];
                foreach ($lines as $line) {
                    if (!trim($line)) continue;
                    $parts=array_map('trim',explode('|',$line));
                    if (count($parts)!==3) sf_fail('Each line must be Name | Country | DDMMYYYY. No rows were imported.');
                    $id=sf_id(); $added[$id]=['id'=>$id,'name'=>sf_text($parts[0]),'country'=>sf_text($parts[1],60),'hash'=>sf_pin($parts[2]),'version'=>1];
                }
                if (count($p['people'])+count($added)>300) sf_fail('A room supports up to 300 participants.');
                $p['people']+=$added; $p['assignments']=[]; break;
            case 'delete_participant':
                sf_draft($p); $id=(string)($input['id'] ?? ''); unset($p['people'][$id],$p['locks'][$id]);
                foreach ($p['locks'] as $a=>$b) if ($b===$id) unset($p['locks'][$a]);
                $p['assignments']=[]; break;
            case 'lock':
                sf_draft($p); $from=(string)($input['from'] ?? ''); $to=(string)($input['to'] ?? '');
                if (!isset($p['people'][$from])) sf_fail('Choose a participant.');
                $locks=$p['locks'];
                if ($to==='') unset($locks[$from]); else $locks[$from]=$to;
                sf_match($p['people'],$locks); $p['locks']=$locks; $p['assignments']=[]; break;
            case 'generate':
                sf_draft($p); sf_match($p['people'],$p['locks']); $p['assignments']=[]; break;
            case 'finalize':
                sf_draft($p);
                sf_match($p['people'],$p['locks']); // Validate feasibility without saving a draw.
                $p['assignments']=[];
                $p['finalized']=gmdate('c'); break;
            case 'admin_result':
                $id=(string)($input['participant'] ?? '');
                if (!isset($p['people'][$id])) sf_fail('Participant not found.',404);
                if (!isset($p['assignments'][$id])) sf_fail('The draw happens when the first agent finishes their mission.',409);
                return ['participant'=>$id,'recipient'=>$p['assignments'][$id]];
            case 'export':
                if (count($p['people'])<2 || count($p['assignments'])!==count($p['people'])) sf_fail('Results are available after the first final reveal.',409);
                $rows=[['Participant','Secret Friend','Participant country','Friend country','Assignment','Same-country warning','Viewed','Reveal timestamp']];
                $cell=fn($s)=>preg_match('/^[\s]*[=+@\-\t\r\n]/u',(string)$s) ? "'".$s : $s;
                foreach ($p['people'] as $id=>$person) {
                    $friend=$p['people'][$p['assignments'][$id] ?? ''] ?? null;
                    $rows[]=array_map($cell,[$person['name'],$friend['name'] ?? '',$person['country'],$friend['country'] ?? '',isset($p['locks'][$id])?'Manual':'Random',$friend && sf_country($person['country'])===sf_country($friend['country'])?'Same country':'',isset($p['viewed'][$id])?'Yes':'No',$p['viewed'][$id] ?? '']);
                }
                return ['csv'=>$rows];
            default: sf_fail('Unknown operation.',404);
        }
        if (count($p['people'])>300) sf_fail('A room supports up to 300 participants.');
        return ['ok'=>true];
    });
    if (isset($out['csv'])) {
        header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="secret-friend-results.csv"');
        $stream=fopen('php://output','w'); foreach ($out['csv'] as $row) fputcsv($stream,$row,',','"',''); fclose($stream);
    } else echo json_encode($out,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    $code=$e instanceof RuntimeException && $e->getCode()>=400 && $e->getCode()<=599 ? $e->getCode() : 500;
    http_response_code($code); echo json_encode(['error'=>$code===500?'The request could not be completed. Check server configuration.':$e->getMessage()]);
}
